Path Flow Chart:

index -> signin/register -> submit -> loggedindex (simulates logged-in)

loggedindex options:
Account -> Profile
Account -> Sign out -> index (simulates logged out)

Products -> cart -> checkout -> Profile
